let nextNumber = 1;
let inputNumber = document.getElementById("inputField");
let counterText = document.getElementById("counterNumber");
let counter = document.getElementById("counterDiv");
let updateButton = document.getElementById("counterButton");
let kiryuMood;
let kiryuNormal =
  "url('https://www.gematsu.com/wp-content/uploads/2012/06/zp-163678_Yakuza-5_2012_06-08-12_003.jpg')";
let kiryuBad = "url('https://i.ytimg.com/vi/7mWBIudE2EA/maxresdefault.jpg')";
let message;
console.log(`Hello! Start by typing ${nextNumber} into the text box.`);
counterText.innerHTML = 0;
updateButton.addEventListener("click", updateCounter);

function updateBackground(mood) {
  document.body.style.backgroundImage = mood;
  switch (mood) {
    case kiryuNormal:
      document.getElementById("main").classList.remove("holyshit");
      console.log("ok");
      break;
    case kiryuBad:
      document.getElementById("main").classList.add("holyshit");
      console.log("not ok");
      break;
  }
}

function counterNumber() {
  console.log(inputNumber.value + " " + nextNumber);
  console.log(inputNumber.value == nextNumber);
  if (inputNumber.value == nextNumber) {
    console.log(`👍🏻 ${nextNumber}`);
    counterText.innerHTML = inputNumber.value;
    nextNumber += 1;
    message = "Next number is " + nextNumber + ".";
    console.log(message);
    kiryuMood = kiryuNormal;
    updateBackground(kiryuMood);
  } else {
    counterText.innerHTML = inputNumber.value;
    message = "You RUINED IT AT " + (nextNumber - 1) + "!!! Next number is 1.";
    nextNumber = 1;
    console.log(message);
    kiryuMood = kiryuBad;
    updateBackground(kiryuMood);
  }
}

function updateCounter() {
  counterNumber();
  counter.innerHTML = message;
}
